"""Собрать автономную доску рядом с планом проекта."""
import os
import sys
import tempfile
from html import escape
from pathlib import Path

STATUSES = ("Сделать", "В работе", "Проверка", "Готово")


def render(source):
    title = None
    intro = []
    cards = {status: [] for status in STATUSES}
    details = intro
    for line in source.splitlines():
        line = line.strip()
        if line.startswith("## "):
            status, sep, label = line[3:].partition("|")
            status = status.strip()
            if not sep or status not in cards or not label.strip():
                raise ValueError(f"Неверный заголовок карточки: {line}")
            details = []
            cards[status].append((label.strip(), details))
        elif line.startswith("# ") and title is None:
            title = escape(line[2:])
        elif line:
            details.append(f"<p>{escape(line)}</p>")
    total = sum(map(len, cards.values()))
    if not title or not total:
        raise ValueError("Плану нужны название и хотя бы одна карточка")
    columns = []
    for status, entries in cards.items():
        items = "".join(f"<article><h3>{escape(label)}</h3>{''.join(body)}</article>"
                        for label, body in entries)
        columns.append(f"<section><h2>{status}</h2>{items}</section>")
    return f"""<!doctype html><html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="10">
<title>{title}</title><style>
*{{box-sizing:border-box}}body{{margin:0 auto;max-width:1500px;padding:4vw;background:#f6f5f1;color:#202b29;font:16px/1.5 Inter,system-ui,sans-serif}}
main{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(245px,100%),1fr));gap:16px;margin-top:32px}}
section{{background:#e7ece8;border-radius:14px;padding:16px}}article{{background:white;border-radius:10px;padding:14px;margin:12px 0;overflow-wrap:anywhere}}
h2,h3,p{{margin:.4em 0}}h2{{font-size:1.15rem}}strong{{color:#14694e}}</style></head>
<body><h1>{title}</h1><strong>Готово {len(cards['Готово'])} из {total}</strong>{''.join(intro)}
<main>{''.join(columns)}</main></body></html>"""


if __name__ == "__main__":
    plan = Path(sys.argv[1])
    board = plan.with_name("doska.html")
    content = render(plan.read_text(encoding="utf-8"))
    with tempfile.NamedTemporaryFile(dir=board.parent, delete=False, mode="w", encoding="utf-8") as out:
        out.write(content)
    os.replace(out.name, board)
    print(board.resolve())
