"""Разбор ячейки из формульной карты. Python 3, только стандартная библиотека."""
import argparse,csv,gzip,json,re
from pathlib import Path
ROOT=Path(__file__).parent
META=json.loads((ROOT/'sheets.json').read_text())
Q=r"(?:'((?:[^']|'')+)'|([\w.]+))!"
P=r'\$?[A-Z]{1,3}\$?\d+'
COL=r'\$?[A-Z]{1,3}'
REF=re.compile(r'(?<![\w$])(?:'+Q+r')?('+r'(?:'+P+'|'+COL+r'|\$?\d+):(?:'+P+'|'+COL+r'|\$?\d+)|'+P+r')(?![\w.(])')
def references(formula,sheet):
    masked=re.sub(r'"(?:[^"]|"")*"','""',formula)
    return list(dict.fromkeys(((m[1] or m[2] or sheet).replace("''","'"),m[3]) for m in REF.finditer(masked)))
def bounds(part,high):
    a=re.fullmatch(r'([A-Z]*)(\d*)',part.replace('$',''));column=0
    for c in a[1]:column=26*column+ord(c)-64
    return column or (10**8 if high else 1),int(a[2] or (10**8 if high else 1))
def contains(area,addr):
    first,_,end=area.partition(':');x,y=bounds(addr,False);a,b=bounds(first,False);c,d=bounds(end or first,True)
    return a<=x<=c and b<=y<=d
def records(ii):
    with gzip.open(ROOT/META[ii]['file'],'rt',encoding='utf-8',newline='') as stream:yield from csv.DictReader(stream,delimiter='\t')
def main():
    p=argparse.ArgumentParser();p.add_argument('sheet',choices=META);p.add_argument('address');p.add_argument('--users',action='store_true',help='найти прямых потребителей по диапазонам');args=p.parse_args();addr=args.address.upper()
    if not re.fullmatch('[A-Z]{1,3}[1-9][0-9]*',addr):p.error('Ожидается один адрес A1')
    row=next((r for r in records(args.sheet) if r['address']==addr),None)
    if row:
        c,n=bounds(addr,False)
        context=json.loads((ROOT/'context.json').read_text())[args.sheet]
        meaning=' · '.join(v for v in (context['rows'].get(str(n)),context['columns'].get(str(c))) if v)
        if meaning:print('Показатель / заголовок:',meaning)
        print('Исходная формула:',row['formula']);print('Операции:',row['meaning']);print('В шаблоне:',row['template'])
        from explain import tree
        print('Порядок расчёта:',*tree(row['formula'].lstrip('=')),sep='\n')
        print('Ссылки:',*['%s!%s'%v for v in references(row['formula'],args.sheet)],sep='\n')
    else:print('В исходной ячейке нет собственной формулы. Проверь inputs, справочник листов и область вывода массивной формулы.')
    if args.users:
        print('Прямые потребители (явные ссылки и диапазоны):')
        for sh in META:
            for r in records(sh):
                if any(z==args.sheet and contains(a,addr) for z,a in references(r['formula'],sh)):print(sh+'!'+r['address'])
if __name__=='__main__':main()
