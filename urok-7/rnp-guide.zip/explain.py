"""Показывает порядок вычисления формулы Sheets без запуска самой формулы."""
import re
FIXED = {
 'IF':('условие','при истине','при лжи'), 'IFERROR':('попробовать вычислить','значение при ошибке'),
 'XLOOKUP':('искомый ключ','где искать','откуда вернуть','если ключ не найден','режим совпадения','порядок поиска'),
 'INDEX':('массив','номер строки','номер столбца'), 'MATCH':('ключ','диапазон поиска','тип совпадения'),
 'SUMIFS':('суммируемые значения',), 'AVERAGEIFS':('усредняемые значения',),
 'AVERAGEIF':('проверяемый диапазон','критерий','что усреднить'), 'COUNTIF':('диапазон','критерий'),
 'FILTER':('что отобрать',),'TEXT':('значение','формат результата'),'TEXTJOIN':('разделитель','пропустить пустые'),
 'DATE':('год','месяц','день'),'EOMONTH':('исходная дата','смещение месяцев'),
 'DATEDIF':('начало','конец','единица интервала'),'HYPERLINK':('адрес','что показать'),
 'SORT':('массив','ключ сортировки','по возрастанию'), 'SEQUENCE':('строк','столбцов','начало','шаг'),
 'SCAN':('начальное значение','массив','функция накопления'),'IMPORTRANGE':('документ','диапазон'),
 'WEEKDAY':('дата','тип нумерации дней'),'IMAGE':('адрес изображения',)}
OP={'=':'равно','<>':'не равно','<':'меньше','>':'больше','<=':'не больше','>=':'не меньше','&':'соединить текст','+':'сложить','-':'вычесть','/':'разделить','*':'умножить','^':'возвести в степень'}
def top(text):
    depth=0; quote=None; i=0
    while i<len(text):
        ch=text[i]
        if quote:
            if ch==quote:
                if i+1<len(text) and text[i+1]==quote:i+=2;continue
                quote=None
        elif ch in ('"',"'"):quote=ch
        elif ch in '({[':depth+=1
        elif ch in ')}]':depth-=1
        elif depth==0:yield i,ch
        i+=1
def parts(text,chars):
    ids=[i for i,ch in top(text) if ch in chars]
    return [text[a+1:b].strip() for a,b in zip([-1]+ids,ids+[len(text)])]
def label(f,i):
    vals=FIXED.get(f,())
    if i<len(vals):return vals[i]
    if f in ('SUMIFS','AVERAGEIFS'):return ('диапазон условия ' if i%2 else 'критерий ')+str((i+1)//2)
    if f=='FILTER':return 'условие '+str(i)
    if f=='IFS':return ('условие ' if i%2==0 else 'результат ')+str(i//2+1)
    if f=='SUMPRODUCT':return 'множитель по строкам '+str(i+1)
    if f in ('IF','IFERROR'):return 'аргумент '+str(i+1)
    return 'вход '+str(i+1)
def tree(expr,depth=0):
    t=expr.strip();pad='  '*depth
    tokens=list(top(t)); candidates=[]
    for n,(i,ch) in enumerate(tokens):
        if ch not in '<>=&+-*/^':continue
        if ch in '+-' and (not t[:i].strip() or t[:i].rstrip()[-1] in '+-/*^=<>&'):continue
        if i and t[i-1] in '<>' and ch in '=>':continue
        op=t[i:i+2] if t[i:i+2] in ('<=','<>','>=') else ch
        level=0 if op in ('=','<>','<','>','<=','>=') else 1 if ch=='&' else 2 if ch in '+-' else 3 if ch in '*/' else 4
        candidates.append((level,-i,op))
    if candidates:
        _,minus,op=min(candidates);i=-minus
        return [pad+OP[op]]+tree(t[:i],depth+1)+tree(t[i+len(op):],depth+1)
    if t.startswith('(') and t.endswith(')'):return tree(t[1:-1],depth)
    m=re.fullmatch(r'([A-Z][A-Z0-9_.]*)\s*\((.*)\)',t,re.I|re.S)
    if m:
        f=m[1].upper();out=[pad+f]
        for i,p in enumerate(parts(m[2],';') if m[2].strip() else []):
            out.append(pad+'  '+label(f,i)+':')
            out.extend(tree(p,depth+2))
        return out
    if t.startswith('{') and t.endswith('}'):
        out=[pad+'собрать массив']
        for v in parts(t[1:-1],';\\'):out.extend(tree(v,depth+1))
        return out
    return [pad+(t or 'пустой аргумент')]
