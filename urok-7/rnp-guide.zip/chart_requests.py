"""Создаёт тело запроса Sheets API для восстановления трёх диаграмм после загрузки данных.
Файл только печатает JSON. Прочитай метаданные копии и проверь ID до применения.
"""
import json
from pathlib import Path
charts=json.loads(Path(__file__).with_name('charts.json').read_text())
print(json.dumps({'requests':[{'updateChartSpec':{'chartId':chart['chartId'],'spec':chart['spec']}} for chart in charts]},ensure_ascii=False))
